package com.eighthlight.affiliate.fixtures;


public class AffiliateService
{

}
