package com.eighthlight.videostore.model;

import org.junit.Assert;
import org.junit.Test;

public class RentalTest extends Assert
{
  @Test
  public void shouldHaveCost() throws Exception
  {

  }
}
