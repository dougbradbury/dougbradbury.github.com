package com.eighthlight.videostore.model;

import org.junit.Assert;
import org.junit.Test;

public class MovieTest extends Assert
{
  @Test
  public void shouldCreateAMovie() throws Exception
  {
    Movie movie = Movie.create("Title", "123barcode123", Movie.NEW_RELEASE);
    assertSame(movie, Movie.find("123barcode123"));
  }

  @Test
  public void shouldCost() throws Exception
  {
    assertEquals(495, Movie.create("Title", "123barcode123", Movie.NEW_RELEASE).cost());
    assertEquals(299, Movie.create("Title", "123barcode123", Movie.LIBRARY).cost());
  }

  @Test
  public void shouldCheckOutMovies() throws Exception
  {
    Movie movie = Movie.create("Woof", "123", Movie.NEW_RELEASE);
    assertFalse(movie.isRented());
    Account account = Account.create("John", "998");
    movie.checkOut(account);
    assertTrue(movie.isRented());
    assertEquals(account, movie.rentedTo());

    assertEquals(1, Movie.rentedTo(account).size());
    assertEquals("Woof", Movie.rentedTo(account).get(0).title);
  }

}
