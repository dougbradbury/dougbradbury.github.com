package com.eighthlight.videostore.model;

import org.junit.Before;
import org.junit.Test;

import java.util.Calendar;

import static junit.framework.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class TransactionTest
{

  private Movie oneMovie;
  private Movie twoMovie;

  @Before
  public void setUp()
  {
    oneMovie = Movie.create("The Dough Chronicles", "2", Movie.NEW_RELEASE);
    twoMovie = Movie.create("The Briman Chronicles", "3", Movie.LIBRARY);
  }

  @Test
  public void shouldAddMovies() throws Exception
  {
    Transaction transaction = new Transaction();
    transaction.addMovie(oneMovie);
    assertEquals(oneMovie.cost(), transaction.total());
  }

  @Test
  public void shouldAddTwoMovies() throws Exception
  {
    Transaction transaction = new Transaction();
    transaction.addMovie(oneMovie);
    transaction.addMovie(twoMovie);
    assertEquals(oneMovie.cost() + twoMovie.cost(), transaction.total());
  }

  @Test
  public void shouldHaveDueDate() throws Exception
  {
    Calendar c1 = Calendar.getInstance();
		c1.set(2011, 2, 20);
    Transaction transaction = new Transaction(c1);
    transaction.addMovie(oneMovie);
    assertEquals(1, transaction.rentalList().size());
    assertEquals(22, transaction.rentalList().get(0).dueOn.get(Calendar.DAY_OF_MONTH));
  }

  @Test
  public void shouldHaveDueDateForLibraryMovieTypes() throws Exception
  {
    Calendar c1 = Calendar.getInstance();
		c1.set(2011, 2, 21);
    Transaction transaction = new Transaction(c1);
    transaction.addMovie(twoMovie);
    assertEquals(1, transaction.rentalList().size());
    assertEquals(26, transaction.rentalList().get(0).dueOn.get(Calendar.DAY_OF_MONTH));
  }

  @Test
  public void shouldAllowOnlyFiveRentalsAtATime() throws Exception
  {
    Transaction transaction = new Transaction();
    assertTrue(transaction.addMovie(oneMovie));
    assertTrue(transaction.addMovie(Movie.create("title", "12", Movie.LIBRARY)));
    assertTrue(transaction.addMovie(Movie.create("title", "13", Movie.LIBRARY)));
    assertTrue(transaction.addMovie(Movie.create("title", "14", Movie.LIBRARY)));
    assertTrue(transaction.addMovie(Movie.create("title", "15", Movie.LIBRARY)));
    assertFalse(transaction.addMovie(Movie.create("title", "16", Movie.LIBRARY)));
    assertEquals(5, transaction.rentalList().size());
  }
}
