package com.eighthlight.videostore.model;

import java.util.Calendar;
import java.util.List;

import static java.lang.Math.min;

public class LateFees
{
  private static final int MILIS_IN_DAY = 1000 * 60 * 60 * 24;
  private static final int FENCE_POST = 1;

  public static int calculate(Calendar today, List<Rental> rentals)
  {
    int fees = 0;
    for(Rental rental : rentals)
    {
      fees += (rental.cost * latePeriods(today, rental));
    }
    return min(2500, fees);
  }

  private static long latePeriods(Calendar today, Rental rental)
  {
    if(!rental.dueOn.before(today))
      return 0;
    long daysLate = differenceInDays(today, rental.dueOn) - FENCE_POST;
    return daysLate / rental.movie.rentalPeriod() + FENCE_POST;
  }

  private static long differenceInDays(Calendar a, Calendar b)
  {
    return (a.getTimeInMillis() - b.getTimeInMillis()) / MILIS_IN_DAY;
  }

}
