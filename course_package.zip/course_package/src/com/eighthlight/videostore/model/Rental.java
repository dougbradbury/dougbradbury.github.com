package com.eighthlight.videostore.model;

import java.util.Calendar;

public class Rental
{
  public int cost;
  public Calendar dueOn;
  public Movie movie;

  public Rental(int cost, Calendar dueOn, Movie movie)
  {
    this.cost = cost;
    this.dueOn = dueOn;
    this.movie = movie;
  }
}
