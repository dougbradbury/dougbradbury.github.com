package com.eighthlight.videostore.model;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Calendar;

import static org.junit.Assert.assertEquals;

public class LateFeesTest
{
  private Calendar today;
  private ArrayList<Rental> rentals;

  @Before
  public void setUp() throws Exception
  {
    today = Calendar.getInstance();
    today.set(2011, 3, 20);
    rentals = new ArrayList<Rental>();

  }

  @Test
  public void shouldHaveNoLateFees() throws Exception
  {
    assertEquals(0, LateFees.calculate(today, rentals));
  }

  @Test
  public void shouldHaveRentalsWithoutFees() throws Exception
  {
    rentals.add(new Rental(100, today, Movie.create("", "", Movie.NEW_RELEASE) ));
    rentals.add(new Rental(100, today, Movie.create("", "", Movie.LIBRARY) ));
    assertEquals(0, LateFees.calculate(today, rentals));
  }

  @Test
  public void shouldHaveOneLateFee() throws Exception
  {
    rentals.add(new Rental(100, oneDayAgo(), Movie.create("", "", Movie.NEW_RELEASE) ));
    assertEquals(100, LateFees.calculate(today, rentals));
  }

  @Test
  public void shouldHaveMultipleLateFees() throws Exception
  {
    rentals.add(new Rental(100, oneDayAgo(), Movie.create("", "", Movie.NEW_RELEASE)));
    rentals.add(new Rental(350, oneDayAgo(), Movie.create("", "", Movie.NEW_RELEASE) ));
    assertEquals(450, LateFees.calculate(today, rentals));
  }

  private Calendar oneDayAgo()
  {
    Calendar oneDayAgo = Calendar.getInstance();
    oneDayAgo.set(2011, 3, 19);
    return oneDayAgo;
  }

  @Test
  public void shouldHaveDoubleLateFees() throws Exception
  {
    Calendar fourDaysAgo = Calendar.getInstance();
    fourDaysAgo.set(2011, 3, 16);
    rentals.add(new Rental(100, fourDaysAgo, Movie.create("", "", Movie.NEW_RELEASE) ));
    assertEquals(200, LateFees.calculate(today, rentals));
  }

}
