package com.eighthlight.videostore.model;

import org.junit.Assert;
import org.junit.Test;

import java.util.Calendar;

public class AccountTest extends Assert
{
  @Test
  public void shouldFindAccount() throws Exception
  {
    Account account = Account.create("John Smith", "1002");
    String id = "1002";

    assertSame(account, Account.find(id.substring(0, 4)));
  }

  @Test
  public void shouldKeepTrackOfRentals() throws Exception
  {
    Account account = Account.create("John Smith", "1002");
    Movie movie = Movie.create("", "12", Movie.LIBRARY);
    Calendar cal = Calendar.getInstance();
    cal.set(2011, 03,01);
    Rental rental = new Rental(150, cal, movie);

    account.addRental(rental);
    assertEquals(1, account.rentals().size());
  }
}
