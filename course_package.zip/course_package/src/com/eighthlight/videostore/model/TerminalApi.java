package com.eighthlight.videostore.model;

import java.util.Calendar;
import java.util.List;

public class TerminalApi
{
  private Account account;
  private Transaction transaction;
  private Calendar today;

  public boolean scanCard(String cardId)
  {
    account = Account.find(cardId);
    transaction = new Transaction(today);
    return account != null;
  }

  public boolean scanMovie(String movieId)
  {
    Movie movie = Movie.find(movieId);
    if(movie != null)
    {
      return transaction.addMovie(movie);
    }
    return false;
  }

  public String patronName()
  {
    if(account == null)
      return "";

    return account.name;
  }

  public List<Rental> rentalList()
  {
    return transaction.rentalList();
  }

  public int total()
  {
    return transaction.total();
  }

  public boolean completeTransaction()
  {
    return transaction.complete(account);
  }


  public int lateFees()
  {
    return LateFees.calculate(today, account.rentals());
  }

  public void todayIs(Calendar today)
  {
    this.today = today;

  }

}
