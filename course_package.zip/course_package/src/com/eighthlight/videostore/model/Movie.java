package com.eighthlight.videostore.model;

import java.util.ArrayList;
import java.util.List;

public class Movie
{
  public static final int NEW_RELEASE = 1;
  public static final int LIBRARY = 2;

  private static ArrayList<Movie> movies = new ArrayList<Movie>();
  public String barCode;
  public String title;
  public int type;
  private Account outTo = null;

  public static Movie create(String title, String barCode, int type)
  {
    Movie movie = new Movie(title, barCode, type);
    movies.add(movie);
    return movie;
  }

  public static Movie find(String barCode)
  {
    for(Movie movie : movies)
    {
      if(movie.barCode.equalsIgnoreCase(barCode))
        return movie;
    }
    return null;
  }

  public int cost()
  {
    if(type == NEW_RELEASE)
    {
      return 495;
    }
    else if(type == LIBRARY)
    {
      return 299;
    }
    return 0;
  }

  public int rentalPeriod()
  {
    if(type == NEW_RELEASE)
    {
      return 2;
    }
    else if(type == LIBRARY)
    {
      return 5;
    }
    return 0;
  }

  private Movie(String title, String barCode, int type)
  {
    this.barCode = barCode;
    this.title = title;
    this.type = type;
  }

  public boolean isRented()
  {
    return outTo != null;
  }

  public void checkOut(Account account)
  {
    this.outTo = account;
  }

  public Account rentedTo()
  {
    return outTo;
  }

  public static List<Movie> rentedTo(Account account)
  {
    ArrayList<Movie> rentedList = new ArrayList<Movie>();

    for(Movie movie : movies)
    {
      if(movie.rentedTo() == account)
        rentedList.add(movie);
    }
    return rentedList;
  }

  public static List<Movie> inStock()
  {
    ArrayList<Movie> rentedList = new ArrayList<Movie>();

    for(Movie movie : movies)
    {
      if(movie.rentedTo() == null)
        rentedList.add(movie);
    }
    return rentedList;
  }

  public static void deleteAll()
  {
    movies.clear();
  }
}
