package com.eighthlight.videostore.model;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class Transaction
{
  private ArrayList<Rental> rentals = new ArrayList<Rental>();
  Calendar today;

  public Transaction()
  {
    today = Calendar.getInstance();
  }

  public Transaction(Calendar time)
  {
    today = time;
  }

  public boolean addMovie(Movie movie)
  {
    if (rentals.size() >= 5)
      return false;

    rentals.add(new Rental(movie.cost(), dueDate(movie, today), movie));
    return true;
  }

  private Calendar dueDate(Movie movie, Calendar today)
  {
    Calendar dueDate = Calendar.getInstance();
    dueDate.setTime(today.getTime());
    dueDate.add(Calendar.DATE, movie.rentalPeriod());
    return dueDate;
  }

  public int total()
  {
    int total = 0;
    for(Rental rental : rentals)
    {
      total += rental.cost;
    }
    return total;
  }

  public List<Rental> rentalList()
  {
    return rentals;
  }

  public boolean complete(Account account)
  {
    if (LateFees.calculate(today, account.rentals()) > 0)
      return false;
    for (Rental rental : rentals)
    {
      rental.movie.checkOut(account);
      account.addRental(rental);
    }
    return true;
  }
}
