package com.eighthlight.videostore.model;

import java.util.ArrayList;
import java.util.List;

public class Account
{
  private static ArrayList<Account> accounts = new ArrayList<Account>();

  public String name;
  private String number;
  private ArrayList<Rental> rentals = new ArrayList<Rental>();


  private Account(String name, String number)
  {
    this.name = name;
    this.number = number;
  }

  public static Account create(String name, String number)
  {
    Account account = new Account(name, number);
    accounts.add(account);
    return account;
  }

  public static Account find(String id)
  {
    for(Account account : accounts)
    {
      if(account.number.equalsIgnoreCase(id))
        return account;
    }
    return null;
  }

  public static void deleteAll()
  {
    accounts.clear();
  }

  public List<Rental> rentals()
  {
    return rentals;
  }

  public void addRental(Rental rental)
  {
    rentals.add(rental);
  }

  public void clearRentals()
  {
    rentals.clear();
  }
}
