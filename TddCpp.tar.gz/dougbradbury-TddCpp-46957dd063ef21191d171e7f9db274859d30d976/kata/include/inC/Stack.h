#ifndef D_Stack_H
#define D_Stack_H

typedef struct Stack Stack;

Stack* Stack_Create(void);
void Stack_Destroy(Stack*);

#endif  // D_Stack_H
