#ifndef ComLink_H
#define ComLink_H
class ComLink
{
  public:
    ComLink(){};
    virtual ~ComLink(){};
};

#endif