#include "PrimeFactors.h"

PrimeFactors::PrimeFactors()
{
}

PrimeFactors::~PrimeFactors()
{
}