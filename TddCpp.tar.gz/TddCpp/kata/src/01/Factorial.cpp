#include "Factorial.h"

Factorial::Factorial()
{
}

Factorial::~Factorial()
{
}