#ifndef D_FakeUptime_H
#define D_FakeUptime_H

/**********************************************************
 *
 * FakeUptime is responsible for providing a
 * test stub for Uptime
 *
 **********************************************************/

#include "Uptime.h"
extern long uptimeMillis;
#endif  /* D_FakeUptime_H */
