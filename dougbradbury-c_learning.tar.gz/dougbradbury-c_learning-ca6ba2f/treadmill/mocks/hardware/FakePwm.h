#ifndef D_FakePwm_H
#define D_FakePwm_H

#include "Pwm.h"

extern int FakePwm_isRunning;
extern int FakePwm_period;
extern double FakePwm_dutyCycle;

#endif  /* D_FakePwm_H */
