#include "Fixtures.h"

SLIM_FIXTURES
  SLIM_FIXTURE(ExampleFixture)
SLIM_END

