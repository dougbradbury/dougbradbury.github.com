#include "Fixtures.h"

SLIM_FIXTURES
  SLIM_FIXTURE(Treadmill)
  SLIM_FIXTURE(TreadmillDistance)
  SLIM_FIXTURE(TreadmillCumulativeDistance)
SLIM_END

