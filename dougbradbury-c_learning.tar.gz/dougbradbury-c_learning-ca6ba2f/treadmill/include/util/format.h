
char * ftoa(char *a, double f, int precision);
