#include "Uptime.h"

void Uptime_Create(void)
{
}

long Uptime_MilliSeconds(void)
{
  return millis();
}

void Uptime_Destroy(void){}
