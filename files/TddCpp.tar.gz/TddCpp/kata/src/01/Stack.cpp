#include "Stack.h"

Stack::Stack()
{
}

Stack::~Stack()
{
}