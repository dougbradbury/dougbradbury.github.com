#include "MessageHandler.h"
#include <string.h>

MessageHandler::MessageHandler()
{
}

MessageHandler::~MessageHandler()
{
}
